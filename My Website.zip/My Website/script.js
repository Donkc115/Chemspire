function showMessage() {
  alert("Welcome to Chemspire! 🚀 Inspiring change through chemistry.");
}